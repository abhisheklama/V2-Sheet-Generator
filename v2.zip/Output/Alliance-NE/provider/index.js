module.exports = [
  {
    _id: "6439491c4704db995fa83c0f",
    title: "Alliance-NE",
    logo: "",
    colors: {},
  },
];
