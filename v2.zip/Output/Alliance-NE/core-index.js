module.exports = {
  providers: "6439491c4704db995fa83c0f",
  plans: {
    "Universal Plus Plan 1": "6439491c4704db995fa83c10",
    "Universal Plus Plan 2": "6439491c4704db995fa83c11",
    "Universal Plus Plan 3": "6439491c4704db995fa83c12",
    "Universal Plan 1": "6439491c4704db995fa83c13",
    "Universal Plan 2": "6439491c4704db995fa83c14",
    "Universal Plan 3": "6439491c4704db995fa83c15",
    "Universal Plan 4": "6439491c4704db995fa83c16",
    "Basic Plan 1": "6439491c4704db995fa83c17",
    "Basic Plan 2": "6439491c4704db995fa83c18",
    "Basic Plan 3": "6439491c4704db995fa83c19",
    "Basic Plan 4": "6439491c4704db995fa83c1a",
    "Basic Plan 5": "6439491c4704db995fa83c1b",
    "Basic Plan 6": "6439491c4704db995fa83c1c",
    "Basic Plan 7": "6439491c4704db995fa83c1d",
    "Basic Plan 8": "6439491c4704db995fa83c1e",
    "Local Plan 1": "6439491c4704db995fa83c1f",
    "Local Plan 2": "6439491c4704db995fa83c20",
    "Local Plan 3": "6439491c4704db995fa83c21",
    "Local Plan 4": "6439491c4704db995fa83c22",
    "Local Plan 5": "6439491c4704db995fa83c23",
    "Local Plan 6": "6439491c4704db995fa83c24",
    "Local Plan 7": "6439491c4704db995fa83c25",
    "Local Plan 8": "6439491c4704db995fa83c26",
    Limited: "6439491c4704db995fa83c27",
  },
  pricingTables: {
    "Universal Plus Plan 1": {
      "Worldwide including USA": "6439491c4704db995fa83c28",
    },
    "Universal Plus Plan 2": {
      "Worldwide including USA": "6439491c4704db995fa83c29",
    },
    "Universal Plus Plan 3": {
      "Worldwide including USA": "6439491c4704db995fa83c2a",
    },
    "Universal Plan 1": {
      "Worldwide excluding USA and Canada": "6439491c4704db995fa83c2b",
    },
    "Universal Plan 2": {
      "Worldwide excluding USA and Canada": "6439491c4704db995fa83c2c",
    },
    "Universal Plan 3": {
      "Worldwide excluding USA and Canada": "6439491c4704db995fa83c2d",
    },
    "Universal Plan 4": {
      "Worldwide excluding USA and Canada": "6439491c4704db995fa83c2e",
    },
    "Basic Plan 1": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c2f",
    },
    "Basic Plan 2": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c30",
    },
    "Basic Plan 3": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c31",
    },
    "Basic Plan 4": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c32",
    },
    "Basic Plan 5": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c33",
    },
    "Basic Plan 6": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c34",
    },
    "Basic Plan 7": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c35",
    },
    "Basic Plan 8": {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c36",
    },
    "Local Plan 1": { UAE: "6439491c4704db995fa83c37" },
    "Local Plan 2": { UAE: "6439491c4704db995fa83c38" },
    "Local Plan 3": { UAE: "6439491c4704db995fa83c39" },
    "Local Plan 4": { UAE: "6439491c4704db995fa83c3a" },
    "Local Plan 5": { UAE: "6439491c4704db995fa83c3b" },
    "Local Plan 6": { UAE: "6439491c4704db995fa83c3c" },
    "Local Plan 7": { UAE: "6439491c4704db995fa83c3d" },
    "Local Plan 8": { UAE: "6439491c4704db995fa83c3e" },
    Limited: {
      "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
        "6439491c4704db995fa83c3f",
    },
  },
  coverages: {
    "Worldwide including USA": "6439491c4704db995fa83c40",
    "Worldwide excluding USA and Canada": "6439491c4704db995fa83c41",
    "UAE, Arab World, Indian Sub-Continent, Sri Lanka, Korea and Philippines":
      "6439491c4704db995fa83c42",
    UAE: "6439491c4704db995fa83c43",
  },
  modifiers: {
    benefits: {
      "Claims Handling": "6439491c4704db995fa83c44",
      "Chronic Condition Cover": "6439491c4704db995fa83c45",
      "Pre-existing Condition Cover": "6439491c4704db995fa83c46",
      "Accommodation Type": "6439491c4704db995fa83c47",
      "In-patient (Hospitalization & Surgery)": "6439491c4704db995fa83c48",
      "Diagnostics & Test": "6439491c4704db995fa83c49",
      "Surgeries & Anesthesia": "6439491c4704db995fa83c4a",
      Oncology: "6439491c4704db995fa83c4b",
      "Organ Transplant": "6439491c4704db995fa83c4c",
      "Out-patient benefits ": "6439491c4704db995fa83c4d",
      "Out-patient Consultations": "6439491c4704db995fa83c4e",
      "Out-patient Specialists": "6439491c4704db995fa83c4f",
      "Out-patient Medicines": "6439491c4704db995fa83c50",
      Vaccination: "6439491c4704db995fa83c51",
      "Scans & Diagnostic Tests": "6439491c4704db995fa83c52",
      Physiotherapy: "6439491c4704db995fa83c53",
      "Maternity (Consultations, Scans and Delivery)":
        "6439491c4704db995fa83c54",
      "Maternity Waiting Period": "6439491c4704db995fa83c55",
      "Complications of Pregnancy": "6439491c4704db995fa83c56",
      "New Born Cover": "6439491c4704db995fa83c57",
      "Dental ": "6439491c4704db995fa83c58",
      "Dental Waiting Period ": "6439491c4704db995fa83c59",
      "Optical Benefits": "6439491c4704db995fa83c5a",
      "Wellness & Health Screening": "6439491c4704db995fa83c5b",
      "Alternative Medicines": "6439491c4704db995fa83c5c",
      "Mental Health Benefit": "6439491c4704db995fa83c5d",
      "Emergency Evacuation": "6439491c4704db995fa83c5e",
      "Virtual / Tele Doctor": "6439491c4704db995fa83c5f",
      "Other Services": "6439491c4704db995fa83c60",
      "Member Web Portal": "6439491c4704db995fa83c61",
      "Mobile Application": "6439491c4704db995fa83c62",
      "Semi Annual Surcharge": "6439491c4704db995fa83c63",
      "Quarterly Surcharge": "6439491c4704db995fa83c64",
      "Monthly Surcharge": "6439491c4704db995fa83c65",
    },
    paymentFrequency: { Annually: "6439491c4704db995fa83c66" },
    deductible: {
      "AED 100": "6439491c4704db995fa83c67",
      "AED 150": "6439491c4704db995fa83c68",
      "AED 200": "6439491c4704db995fa83c69",
      "AED 50": "6439491c4704db995fa83c6a",
      "AED 75": "6439491c4704db995fa83c6b",
    },
    discount: { familyDiscount: "6439491c4704db995fa83c6c" },
    network: {
      "Nextcare GN": "6439491c4704db995fa83c6d",
      "Nextcare RN": "6439491c4704db995fa83c6e",
      "Nextcae RN2 (OP restricted to clinics)": "6439491c4704db995fa83c6f",
    },
  },
};
