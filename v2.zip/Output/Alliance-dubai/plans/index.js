module.exports = [
  {
    _id: "6436541d1fdffe9477c115df",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plus",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115e6"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e0",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115e7"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e1",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115e8"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e2",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115e9"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e3",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115ea"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e4",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115eb"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6436541d1fdffe9477c115e5",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Limited",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6436541d1fdffe9477c115f1"] },
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c115f2",
              "6436541d1fdffe9477c115f3",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c115f4"] },
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115f5"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115f6",
              "6436541d1fdffe9477c115f7",
              "6436541d1fdffe9477c115f8",
              "6436541d1fdffe9477c115f9",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6436541d1fdffe9477c115fa"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c115fb",
              "6436541d1fdffe9477c115fc",
              "6436541d1fdffe9477c115fd",
              "6436541d1fdffe9477c115fe",
              "6436541d1fdffe9477c115ff",
            ],
          },
          { userType: "All", benefitTypes: ["6436541d1fdffe9477c11600"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11601",
              "6436541d1fdffe9477c11602",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11603",
              "6436541d1fdffe9477c11604",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11605",
              "6436541d1fdffe9477c11606",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11607",
              "6436541d1fdffe9477c11608",
              "6436541d1fdffe9477c1160b",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6436541d1fdffe9477c11609",
              "6436541d1fdffe9477c1160a",
              "6436541d1fdffe9477c1160c",
              "6436541d1fdffe9477c1160d",
              "6436541d1fdffe9477c1160e",
              "6436541d1fdffe9477c1160f",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6436541d1fdffe9477c11610",
              "6436541d1fdffe9477c11611",
              "6436541d1fdffe9477c11612",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6436541d1fdffe9477c115ec"],
    modifiers: [
      "6436541d1fdffe9477c115f1",
      "6436541d1fdffe9477c115f2",
      "6436541d1fdffe9477c115f3",
      "6436541d1fdffe9477c115f4",
      "6436541d1fdffe9477c115f5",
      "6436541d1fdffe9477c115f6",
      "6436541d1fdffe9477c115f7",
      "6436541d1fdffe9477c115f8",
      "6436541d1fdffe9477c115f9",
      "6436541d1fdffe9477c115fa",
      "6436541d1fdffe9477c115fb",
      "6436541d1fdffe9477c115fc",
      "6436541d1fdffe9477c115fd",
      "6436541d1fdffe9477c115fe",
      "6436541d1fdffe9477c115ff",
      "6436541d1fdffe9477c11600",
      "6436541d1fdffe9477c11601",
      "6436541d1fdffe9477c11602",
      "6436541d1fdffe9477c11603",
      "6436541d1fdffe9477c11604",
      "6436541d1fdffe9477c11605",
      "6436541d1fdffe9477c11606",
      "6436541d1fdffe9477c11607",
      "6436541d1fdffe9477c11608",
      "6436541d1fdffe9477c11609",
      "6436541d1fdffe9477c1160a",
      "6436541d1fdffe9477c1160b",
      "6436541d1fdffe9477c1160c",
      "6436541d1fdffe9477c1160d",
      "6436541d1fdffe9477c1160e",
      "6436541d1fdffe9477c1160f",
      "6436541d1fdffe9477c11610",
      "6436541d1fdffe9477c11611",
      "6436541d1fdffe9477c11612",
      "6436541d1fdffe9477c11613",
      "6436541d1fdffe9477c11614",
      "6436541d1fdffe9477c11615",
      "6436541d1fdffe9477c11616",
      "6436541d1fdffe9477c11617",
      "6436541d1fdffe9477c11618",
    ],
  },
  {
    _id: "6439491c4704db995fa83c10",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plus Plan 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c28"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c11",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plus Plan 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c29"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c12",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plus Plan 3",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2a"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c13",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plan 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2b"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c14",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plan 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2c"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c15",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plan 3",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2d"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c16",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Universal Plan 4",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2e"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c17",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c2f"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c18",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c30"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c19",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 3",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c31"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1a",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 4",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c32"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1b",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 5",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c33"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1c",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 6",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c34"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1d",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 7",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c35"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1e",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Basic Plan 8",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c36"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c1f",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 1",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c37"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c20",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 2",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c38"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c21",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 3",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c39"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c22",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 4",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3a"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c23",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 5",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3b"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c24",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 6",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3c"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c25",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 7",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3d"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c26",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Local Plan 8",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3e"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
  {
    _id: "6439491c4704db995fa83c27",
    tmpPath: "",
    provider: "6436541d1fdffe9477c115de",
    title: "Limited",
    notes: "",
    benefitCategories: [
      {
        categoryTitle: "General Benefits",
        includedBenefits: [
          { userType: "Pro", benefitTypes: ["6439491c4704db995fa83c44"] },
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c45",
              "6439491c4704db995fa83c46",
            ],
          },
        ],
      },
      {
        categoryTitle: "In-patient (Hospitalization & Surgery)",
        includedBenefits: [
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c47"] },
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c48"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c49",
              "6439491c4704db995fa83c4a",
              "6439491c4704db995fa83c4b",
              "6439491c4704db995fa83c4c",
            ],
          },
        ],
      },
      {
        categoryTitle:
          "Out-patient (Consultations, Lab & Diagnostics, Pharmacy, Physiotherapy)",
        includedBenefits: [
          { userType: "Starter", benefitTypes: ["6439491c4704db995fa83c4d"] },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c4e",
              "6439491c4704db995fa83c4f",
              "6439491c4704db995fa83c50",
              "6439491c4704db995fa83c51",
              "6439491c4704db995fa83c52",
            ],
          },
          { userType: "All", benefitTypes: ["6439491c4704db995fa83c53"] },
        ],
      },
      {
        categoryTitle: "Maternity",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c54",
              "6439491c4704db995fa83c55",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c56",
              "6439491c4704db995fa83c57",
            ],
          },
        ],
      },
      {
        categoryTitle: "Dental Benefit",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c58",
              "6439491c4704db995fa83c59",
            ],
          },
        ],
      },
      {
        categoryTitle: "Additional Benefits",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c5a",
              "6439491c4704db995fa83c5b",
              "6439491c4704db995fa83c5e",
            ],
          },
          {
            userType: "Pro",
            benefitTypes: [
              "6439491c4704db995fa83c5c",
              "6439491c4704db995fa83c5d",
              "6439491c4704db995fa83c5f",
              "6439491c4704db995fa83c60",
              "6439491c4704db995fa83c61",
              "6439491c4704db995fa83c62",
            ],
          },
        ],
      },
      {
        categoryTitle: "Modes of Payment",
        includedBenefits: [
          {
            userType: "All",
            benefitTypes: [
              "6439491c4704db995fa83c63",
              "6439491c4704db995fa83c64",
              "6439491c4704db995fa83c65",
            ],
          },
        ],
      },
    ],
    pricingTables: ["6439491c4704db995fa83c3f"],
    modifiers: [
      "6439491c4704db995fa83c44",
      "6439491c4704db995fa83c45",
      "6439491c4704db995fa83c46",
      "6439491c4704db995fa83c47",
      "6439491c4704db995fa83c48",
      "6439491c4704db995fa83c49",
      "6439491c4704db995fa83c4a",
      "6439491c4704db995fa83c4b",
      "6439491c4704db995fa83c4c",
      "6439491c4704db995fa83c4d",
      "6439491c4704db995fa83c4e",
      "6439491c4704db995fa83c4f",
      "6439491c4704db995fa83c50",
      "6439491c4704db995fa83c51",
      "6439491c4704db995fa83c52",
      "6439491c4704db995fa83c53",
      "6439491c4704db995fa83c54",
      "6439491c4704db995fa83c55",
      "6439491c4704db995fa83c56",
      "6439491c4704db995fa83c57",
      "6439491c4704db995fa83c58",
      "6439491c4704db995fa83c59",
      "6439491c4704db995fa83c5a",
      "6439491c4704db995fa83c5b",
      "6439491c4704db995fa83c5c",
      "6439491c4704db995fa83c5d",
      "6439491c4704db995fa83c5e",
      "6439491c4704db995fa83c5f",
      "6439491c4704db995fa83c60",
      "6439491c4704db995fa83c61",
      "6439491c4704db995fa83c62",
      "6439491c4704db995fa83c63",
      "6439491c4704db995fa83c64",
      "6439491c4704db995fa83c65",
      "6439491c4704db995fa83c66",
      "6439491c4704db995fa83c67",
      "6439491c4704db995fa83c68",
      "6439491c4704db995fa83c69",
      "6439491c4704db995fa83c6a",
      "6439491c4704db995fa83c6b",
      "6439491c4704db995fa83c6c",
      "6439491c4704db995fa83c6d",
      "6439491c4704db995fa83c6e",
      "6439491c4704db995fa83c6f",
    ],
  },
];
